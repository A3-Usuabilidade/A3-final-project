import { useState, useEffect } from 'react';
import api from '../servicos/api.js';

export default function useDashboard() {
  const [kpis, setKpis] = useState({ usuarios: 0, jogos: 0, empresas: 0, vendas: 0 });
  const [topJogos, setTopJogos] = useState([]);
  const [jogosPorEmpresa, setJogosPorEmpresa] = useState([]);
  const [rankingCategorias, setRankingCategorias] = useState([]);
  const [empresas, setEmpresas] = useState([]);
  const [empresaSelecionada, setEmpresaSelecionada] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [carregandoEmpresa, setCarregandoEmpresa] = useState(false);
  const [erro, setErro] = useState(null);

  useEffect(() => {
    Promise.all([
      api.get('/usuarios'),
      api.get('/jogos'),
      api.get('/empresas'),
      api.get('/categorias'),
      api.get('/relatorios/jogos-mais-vendidos', { params: { top: 9999 } }),
    ])
      .then(([usuariosRes, jogosRes, empresasRes, categoriasRes, relatorioRes]) => {
        const todosJogos    = jogosRes.data      || [];
        const todasEmpresas = empresasRes.data   || [];
        const todasCats     = categoriasRes.data || [];
        const vendas        = relatorioRes.data  || [];

        const totalVendas = vendas.reduce((s, v) => s + v.total_vendas, 0);

        // Ranking por categoria: cruzar nome do jogo (relatorio) com fkCategoria (jogos)
        const porNome  = Object.fromEntries(todosJogos.map(j => [j.nome, j]));
        const porCatId = Object.fromEntries(todasCats.map(c => [c.id, c.nome]));
        const totalCat = {};
        vendas.forEach(v => {
          const jogo    = porNome[v.jogo];
          if (!jogo) return;
          const catNome = porCatId[jogo.fkCategoria] ?? 'Sem categoria';
          totalCat[catNome] = (totalCat[catNome] || 0) + v.total_vendas;
        });
        const rankingCat = Object.entries(totalCat)
          .map(([categoria, total_vendas]) => ({ categoria, total_vendas }))
          .sort((a, b) => b.total_vendas - a.total_vendas);

        setKpis({ usuarios: usuariosRes.data.length, jogos: todosJogos.length, empresas: todasEmpresas.length, vendas: totalVendas });
        setTopJogos(vendas);
        setEmpresas(todasEmpresas);
        setRankingCategorias(rankingCat);
      })
      .catch(() => setErro('Erro ao carregar dados do dashboard'))
      .finally(() => setCarregando(false));
  }, []);

  useEffect(() => {
    if (!empresaSelecionada) { setJogosPorEmpresa([]); return; }
    setCarregandoEmpresa(true);
    api.get('/relatorios/jogos-mais-vendidos', { params: { top: 10, empresa: empresaSelecionada } })
      .then(res => setJogosPorEmpresa(res.data || []))
      .catch(() => setJogosPorEmpresa([]))
      .finally(() => setCarregandoEmpresa(false));
  }, [empresaSelecionada]);

  return {
    kpis, topJogos, jogosPorEmpresa, rankingCategorias,
    empresas, empresaSelecionada, setEmpresaSelecionada,
    carregando, carregandoEmpresa, erro,
  };
}
